// Entities/Product.ts
export class Product {
    constructor(public name: string, public price: number) {}
}